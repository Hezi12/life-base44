import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Target, ArrowLeft, Clock, Calendar } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { FocusSession } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import moment from 'moment';

export default function ActiveFocusSession() {
    const [content, setContent] = useState('');
    const [sessionNumber, setSessionNumber] = useState(0);
    const [sessionStart, setSessionStart] = useState(null);
    const [duration, setDuration] = useState(0);
    const [isFinishDialogOpen, setIsFinishDialogOpen] = useState(false);
    const [nextSessionTime, setNextSessionTime] = useState('');
    const [isFinishing, setIsFinishing] = useState(false);
    const navigate = useNavigate();

    // שמירה אוטומטית עם debounce לתוכן המיקוד
    useEffect(() => {
        if (sessionNumber === 0 || content === '') return;
        
        const saveTimer = setTimeout(() => {
            localStorage.setItem(`focus_session_${sessionNumber}_backup`, content);
        }, 3000);

        return () => clearTimeout(saveTimer);
    }, [content, sessionNumber]);

    // טעינת גיבוי אם קיים
    useEffect(() => {
        if (sessionNumber === 0) return;

        const backup = localStorage.getItem(`focus_session_${sessionNumber}_backup`);
        if (backup && content === '') {
            setContent(backup);
        }
    }, [sessionNumber, content]);

    // מציאת מספר הסשן הבא ויצירת סשן חדש
    useEffect(() => {
        const initializeSession = async () => {
            const now = new Date();
            setSessionStart(now);

            const lastSession = await FocusSession.list('-session_number', 1);
            const nextNumber = lastSession.length > 0 ? lastSession[0].session_number + 1 : 1;
            setSessionNumber(nextNumber);

            const nextHour = new Date(now.getTime() + 60 * 60 * 1000);
            setNextSessionTime(moment(nextHour).format('YYYY-MM-DDTHH:mm'));
        };

        initializeSession();
    }, []);

    // טיימר למשך הזמן
    useEffect(() => {
        if (!sessionStart) return;

        const interval = setInterval(() => {
            const now = new Date();
            const diffInMinutes = Math.floor((now - sessionStart) / (1000 * 60));
            setDuration(diffInMinutes);
        }, 1000);

        return () => clearInterval(interval);
    }, [sessionStart]);

    const handleFinishSession = async () => {
        if (!content.trim()) {
            alert('נא לכתוב משהו במיקוד לפני הסיום');
            return;
        }

        setIsFinishing(true);

        try {
            const now = new Date();
            const durationMinutes = Math.floor((now - sessionStart) / (1000 * 60));

            const aiSummary = await InvokeLLM({
                prompt: `אנא קרא את המיקוד הזה וכתוב ממנו סיכום של 2-3 שורות שיעזור לאדם להבין מה הוא עבר במיקוד הזה. כתוב בעברית:

"${content}"`,
            });

            const aiAffirmation = await InvokeLLM({
                prompt: `על בסיס המיקוד הזה, כתוב משפט אחד מחזק ומעודד (affirmation) שיעזור לאדם להרגיש טוב עם עצמו. כתוב בעברית:

"${content}"`,
            });

            const templateFormat = `מיקוד ${sessionNumber} – ${moment(sessionStart).format('DD/MM/YYYY')} | ${moment(sessionStart).format('HH:mm')}

${content}

→ המיקוד הבא ${moment(nextSessionTime).format('HH:mm DD/MM/YYYY')}`;

            const sessionData = {
                session_number: sessionNumber,
                start_time: sessionStart.toISOString(),
                end_time: now.toISOString(),
                duration_minutes: durationMinutes,
                content: content,
                ai_summary: aiSummary,
                ai_affirmation: aiAffirmation,
                next_session_suggestion: nextSessionTime ? moment(nextSessionTime).toISOString() : null,
                template_format: templateFormat
            };

            await FocusSession.create(sessionData);
            localStorage.removeItem(`focus_session_${sessionNumber}_backup`);

            navigate(createPageUrl(`Dashboard?session=${sessionNumber}`));
        } catch (error) {
            console.error('Error finishing session:', error);
            alert('שגיאה בשמירת המיקוד. נסה שוב.');
        } finally {
            setIsFinishing(false);
        }
    };

    return (
        <div className="min-h-screen bg-white flex flex-col p-4" dir="rtl">
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-4">
                    <Link to={createPageUrl("Focus")}>
                        <Button variant="ghost" size="icon">
                            <ArrowLeft className="w-5 h-5 text-gray-600" />
                        </Button>
                    </Link>
                    <div className="flex items-center gap-3">
                        <Target className="w-6 h-6 text-blue-600" />
                        <h1 className="text-xl font-light text-black">מיקוד #{sessionNumber}</h1>
                    </div>
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{duration} דקות</span>
                    </div>
                    {sessionStart && (
                        <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>{moment(sessionStart).format('HH:mm')}</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 max-w-4xl mx-auto w-full">
                <Card className="h-full border-gray-100 shadow-none">
                    <CardContent className="p-6 h-full flex flex-col">
                        <Textarea
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            placeholder="התחל לכתוב כאן..."
                            className="flex-1 resize-none border-none focus-visible:ring-0 text-base leading-relaxed"
                            style={{ minHeight: '400px' }}
                        />
                    </CardContent>
                </Card>
            </div>

            {/* Footer */}
            <div className="mt-6 flex justify-center">
                <Button 
                    onClick={() => setIsFinishDialogOpen(true)}
                    disabled={!content.trim()}
                    className="bg-blue-600 hover:bg-blue-700 px-8"
                >
                    סיים מיקוד
                </Button>
            </div>

            {/* Finish Dialog */}
            <Dialog open={isFinishDialogOpen} onOpenChange={setIsFinishDialogOpen}>
                <DialogContent className="max-w-md" dir="rtl">
                    <DialogHeader>
                        <DialogTitle className="text-right">סיים מיקוד</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div>
                            <Label htmlFor="nextSession" className="text-sm font-medium">
                                מתי המיקוד הבא?
                            </Label>
                            <Input
                                id="nextSession"
                                type="datetime-local"
                                value={nextSessionTime}
                                onChange={(e) => setNextSessionTime(e.target.value)}
                                className="mt-1"
                            />
                        </div>
                    </div>
                    <DialogFooter className="flex justify-start">
                        <Button 
                            onClick={handleFinishSession}
                            disabled={isFinishing}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {isFinishing ? 'שומר...' : 'שמור וסיים'}
                        </Button>
                        <Button 
                            variant="outline" 
                            onClick={() => setIsFinishDialogOpen(false)}
                        >
                            ביטול
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}