
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, Settings, History, Plus, Trash2 } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { FocusSession } from '@/api/entities';
import { FocusSetting } from '@/api/entities';
import moment from 'moment';

const RadioToggle = ({ id, checked, onCheckedChange }) => {
    return (
        <button
            id={id}
            role="switch"
            aria-checked={checked}
            onClick={() => onCheckedChange(!checked)}
            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${checked ? 'border-blue-600' : 'border-gray-300'}`}
        >
            {checked && <div className="w-3 h-3 bg-blue-600 rounded-full"></div>}
        </button>
    );
};

export default function Focus() {
    const [nextFocusTime, setNextFocusTime] = useState(null);
    const [nextSessionNumber, setNextSessionNumber] = useState(1);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isScheduleManagementOpen, setIsScheduleManagementOpen] = useState(false);
    const [settings, setSettings] = useState({
        schedule: [],
        notification_minutes_before: 15,
        notify_on_time: true
    });
    const [selectedDays, setSelectedDays] = useState([]);
    const [newScheduleTime, setNewScheduleTime] = useState('');

    // פונקציה למציאת הזמן הקבוע הקרוב ביותר
    const getNextScheduledTime = (schedule) => {
        if (!schedule || schedule.length === 0) return null;

        const now = moment();
        const currentDay = now.day(); // 0 = Sunday, 1 = Monday, etc.
        const currentTimeMinutes = now.hours() * 60 + now.minutes();

        const dayOrder = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        
        // חיפוש זמן מהיום
        const todaySchedules = schedule.filter(s => s.day === dayOrder[currentDay]);
        todaySchedules.sort((a, b) => a.time.localeCompare(b.time));

        for (const todaySchedule of todaySchedules) {
            const [hours, minutes] = todaySchedule.time.split(':').map(Number);
            const scheduleTimeMinutes = hours * 60 + minutes;
            
            if (scheduleTimeMinutes > currentTimeMinutes) {
                const nextTime = moment(now).hours(hours).minutes(minutes).seconds(0);
                return nextTime.toDate();
            }
        }
        
        // חיפוש בימים הבאים
        for (let daysAhead = 1; daysAhead <= 7; daysAhead++) {
            const targetDayIndex = (currentDay + daysAhead) % 7;
            const targetDayName = dayOrder[targetDayIndex];
            const targetSchedules = schedule.filter(s => s.day === targetDayName);
            
            if (targetSchedules.length > 0) {
                const earliestSchedule = targetSchedules.sort((a, b) => a.time.localeCompare(b.time))[0];
                const [hours, minutes] = earliestSchedule.time.split(':').map(Number);
                
                const nextTime = moment(now).add(daysAhead, 'days').hours(hours).minutes(minutes).seconds(0);
                return nextTime.toDate();
            }
        }
        
        return null;
    };

    useEffect(() => {
        const fetchData = async () => {
            // טען מספר המיקוד הבא
            const lastSession = await FocusSession.list('-session_number', 1);
            const nextNumber = lastSession.length > 0 ? lastSession[0].session_number + 1 : 1;
            setNextSessionNumber(nextNumber);
            
            // טען הגדרות
            const existingSettings = await FocusSetting.list();
            let currentSettings = { schedule: [], notification_minutes_before: 15, notify_on_time: true };
            if (existingSettings.length > 0) {
                currentSettings = existingSettings[0];
                setSettings(currentSettings);
            }
            
            // טען מיקוד הבא
            if (lastSession.length > 0 && lastSession[0].next_session_suggestion) {
                setNextFocusTime(new Date(lastSession[0].next_session_suggestion));
            } else {
                const scheduledTime = getNextScheduledTime(currentSettings.schedule);
                if (scheduledTime) {
                    setNextFocusTime(scheduledTime);
                } else {
                    const defaultTime = moment().add(1, 'hour').startOf('hour').toDate();
                    setNextFocusTime(defaultTime);
                }
            }
        };
        fetchData();
    }, []);

    const handleTimeChange = (e) => {
        setNextFocusTime(moment(e.target.value, 'YYYY-MM-DDTHH:mm').toDate());
    };

    const toggleDay = (day) => {
        if (selectedDays.includes(day)) {
            setSelectedDays(selectedDays.filter(d => d !== day));
        } else {
            setSelectedDays([...selectedDays, day]);
        }
    };

    const addScheduleTime = async () => {
        if (selectedDays.length > 0 && newScheduleTime) {
            const newSchedules = selectedDays.map(day => ({ day, time: newScheduleTime }));
            const newSchedule = [...settings.schedule, ...newSchedules];
            const newSettings = {...settings, schedule: newSchedule};
            setSettings(newSettings);
            
            // שמור מיד לבסיס הנתונים
            const existingSettings = await FocusSetting.list();
            if (existingSettings.length > 0) {
                await FocusSetting.update(existingSettings[0].id, newSettings);
            } else {
                await FocusSetting.create(newSettings);
            }
            
            setSelectedDays([]);
            setNewScheduleTime('');
        }
    };

    const removeScheduleGroup = async (time) => {
        const newSchedule = settings.schedule.filter(s => s.time !== time);
        const newSettings = {...settings, schedule: newSchedule};
        setSettings(newSettings);
        
        // שמור מיד לבסיס הנתונים
        const existingSettings = await FocusSetting.list();
        if (existingSettings.length > 0) {
            await FocusSetting.update(existingSettings[0].id, newSettings);
        }
    };

    const saveSettings = async () => {
        const existingSettings = await FocusSetting.list();
        if (existingSettings.length > 0) {
            await FocusSetting.update(existingSettings[0].id, settings);
        } else {
            await FocusSetting.create(settings);
        }
        setIsSettingsOpen(false);
        setIsScheduleManagementOpen(false);
    };

    const dayNames = {
        Sunday: 'א׳',
        Monday: 'ב׳', 
        Tuesday: 'ג׳',
        Wednesday: 'ד׳',
        Thursday: 'ה׳',
        Friday: 'ו׳',
        Saturday: 'ש׳'
    };

    // קיבוץ זמנים לפי שעה
    const groupedSchedules = settings.schedule.reduce((groups, schedule) => {
        const time = schedule.time;
        if (!groups[time]) {
            groups[time] = [];
        }
        if (!groups[time].includes(schedule.day)) {
            groups[time].push(schedule.day);
        }
        return groups;
    }, {});

    return (
        <div className="min-h-screen bg-white flex flex-col" dir="rtl">
            {/* Header - קומפקטי יותר */}
            <div className="flex justify-between items-center p-4 sm:p-6">
                <h1 className="text-xl sm:text-2xl font-light text-black">מיקוד</h1>
                <div className="flex gap-1 sm:gap-2">
                    <Link to={createPageUrl("FocusHistory")}>
                        <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-10 sm:w-10">
                            <History className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                        </Button>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)} className="h-8 w-8 sm:h-10 sm:w-10">
                        <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                    </Button>
                </div>
            </div>

            {/* Main content area - ממורכז בדף */}
            <div className="flex-1 flex items-center justify-center px-4">
                <div className="w-full max-w-sm text-center space-y-16">
                    {/* Play button - במרכז הדף */}
                    <div>
                        <Link to={createPageUrl("ActiveFocusSession")}>
                            <Button 
                                variant="outline" 
                                className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-2 border-gray-300 hover:border-blue-500 bg-white hover:bg-blue-50 shadow-sm hover:shadow-md transition-all duration-200 transform hover:scale-105"
                            >
                                <Play className="w-8 h-8 sm:w-10 sm:h-10 text-gray-700 hover:text-blue-600 transition-colors transform translate-x-0.5" />
                            </Button>
                        </Link>
                    </div>

                    {/* Next focus time with number */}
                    <div>
                        <Card className="w-fit mx-auto border-gray-100 shadow-none">
                            <CardContent className="p-3 sm:p-4">
                                <input 
                                    type="datetime-local"
                                    value={nextFocusTime ? moment(nextFocusTime).format('YYYY-MM-DDTHH:mm') : ''}
                                    onChange={handleTimeChange}
                                    className="text-center bg-transparent border-none focus:ring-0 text-base sm:text-lg font-medium text-gray-800 w-full"
                                />
                            </CardContent>
                        </Card>
                        <p className="text-xs sm:text-sm text-gray-500 mt-2">מיקוד הבא #{nextSessionNumber}</p>
                    </div>
                </div>
            </div>

            {/* Settings Dialog - מותאם למובייל */}
            <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
                <DialogContent className="sm:max-w-[500px] w-[95vw] max-h-[90vh] overflow-y-auto [&>button]:hidden" dir="rtl">
                    <DialogHeader className="text-right">
                        <DialogTitle className="text-right">הגדרות מיקוד</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-6 py-4">
                        {/* Schedule Management - מותאם למובייל */}
                        <div>
                            <div className="flex items-center justify-between mb-3">
                                <Label className="text-sm sm:text-base font-medium">זמנים קבועים למיקוד</Label>
                                <Button 
                                    variant="ghost" 
                                    size="icon"
                                    onClick={() => {
                                        setIsScheduleManagementOpen(true);
                                        setSelectedDays([]); 
                                        setNewScheduleTime('');
                                    }}
                                    className="h-7 w-7 sm:h-8 sm:w-8"
                                >
                                    <Plus className="w-3 h-3 sm:w-4 sm:h-4 text-gray-600" />
                                </Button>
                            </div>

                            {/* Display current schedules */}
                            {Object.keys(groupedSchedules).length > 0 && (
                                <div className="space-y-2">
                                    {Object.entries(groupedSchedules).map(([time, days]) => (
                                        <div key={time} className="flex items-center justify-between border rounded-lg p-2 sm:p-3 bg-gray-50">
                                            <div className="flex items-center gap-2 sm:gap-3">
                                                <span className="text-sm sm:text-base font-medium">{time}</span>
                                                <span className="text-xs sm:text-sm text-gray-600">
                                                    בימים {days.map(day => dayNames[day]).join(' ')}
                                                </span>
                                            </div>
                                            <Button 
                                                variant="ghost" 
                                                size="icon" 
                                                onClick={() => removeScheduleGroup(time)}
                                                className="h-6 w-6 sm:h-8 sm:w-8 text-red-500 hover:text-red-700"
                                            >
                                                <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Notification settings - מותאם למובייל */}
                        <div className="flex items-center justify-between">
                            <Label htmlFor="notify_on_time" className="text-sm sm:text-base">התראה בזמן המיקוד</Label>
                            <RadioToggle 
                                id="notify_on_time" 
                                checked={settings.notify_on_time} 
                                onCheckedChange={(checked) => setSettings({...settings, notify_on_time: checked})}
                            />
                        </div>

                        <div className="grid grid-cols-3 items-center gap-2 sm:gap-4">
                            <Label htmlFor="notification_minutes" className="text-right text-sm sm:text-base">התראה לפני (דקות)</Label>
                            <Input 
                                id="notification_minutes" 
                                type="number" 
                                value={settings.notification_minutes_before}
                                onChange={(e) => setSettings({...settings, notification_minutes_before: parseInt(e.target.value)})}
                                className="col-span-1 w-12 sm:w-16 text-sm" 
                            />
                        </div>
                    </div>
                    <DialogFooter className="flex justify-start">
                        <Button 
                            onClick={saveSettings}
                            className="bg-blue-50 text-blue-600 hover:bg-blue-100"
                            size="sm"
                        >
                            שמור הגדרות
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Schedule Management Dialog - מותאם למובייל */}
            <Dialog open={isScheduleManagementOpen} onOpenChange={setIsScheduleManagementOpen}>
                <DialogContent className="sm:max-w-[400px] w-[95vw] max-h-[90vh] overflow-y-auto [&>button]:hidden" dir="rtl">
                    <DialogHeader className="text-right">
                        <DialogTitle className="text-right text-base sm:text-lg">הוסף זמן מיקוד קבוע</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        {/* Day selection - מותאם למובייל */}
                        <div>
                            <Label className="text-xs sm:text-sm text-gray-600 mb-2 block">ימים:</Label>
                            <div className="flex gap-1 flex-wrap">
                                {Object.entries(dayNames).map(([dayKey, dayName]) => (
                                    <Button
                                        key={dayKey}
                                        variant={selectedDays.includes(dayKey) ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => toggleDay(dayKey)}
                                        className={`h-7 w-7 sm:h-8 sm:w-8 p-0 text-xs ${selectedDays.includes(dayKey) ? 'bg-blue-500 text-white' : ''}`}
                                    >
                                        {dayName}
                                    </Button>
                                ))}
                            </div>
                        </div>

                        {/* Time selection - מותאם למובייל */}
                        <div>
                            <Label className="text-xs sm:text-sm text-gray-600 mb-2 block">שעה:</Label>
                            <Input 
                                type="time" 
                                value={newScheduleTime} 
                                onChange={(e) => setNewScheduleTime(e.target.value)}
                                className="w-28 sm:w-32 text-sm"
                            />
                        </div>
                    </div>
                    <DialogFooter className="flex justify-between">
                        <Button 
                            onClick={() => setIsScheduleManagementOpen(false)}
                            variant="outline"
                            size="sm"
                        >
                            ביטול
                        </Button>
                        <Button 
                            onClick={addScheduleTime}
                            disabled={selectedDays.length === 0 || !newScheduleTime}
                            className="bg-blue-50 text-blue-600 hover:bg-blue-100"
                            size="sm"
                        >
                            הוסף
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
